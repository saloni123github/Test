package com.saloni.velocity.quiz;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



		
		public class Sorting {
		   static final String DB_URL = "jdbc:mysql://localhost/user";
		   static final String USER = "root";
		   static final String PASS = "Saloni@123";
		   static final String QUERY = "SELECT student_id,student_name ,student_score  FROM students";

		   public void sorting() {
		      // Open a connection
		      try(Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
		         Statement stmt = conn.createStatement();) {		      
		         System.out.println("Fetching records in ascending order...");
		         ResultSet rs = stmt.executeQuery(QUERY + " ORDER BY student_score asc");
		         while(rs.next()){
		            //Display values
		            System.out.println("ID: " + rs.getInt("student_id"));
		            System.out.println(", NAME: " + rs.getString("student_name"));
		            System.out.println(", SCORE: " + rs.getInt("student_score"));
		           
		         }

		        
		         rs.close();
		      } catch (SQLException e) {
		         e.printStackTrace();
		      } 
		   }
		

	}


