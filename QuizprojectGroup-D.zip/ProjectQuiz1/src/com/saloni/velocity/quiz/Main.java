package com.saloni.velocity.quiz;


public class Main {

public static void main(String[] args) {
	
	Quiz q=new Quiz();
	q.logic();
	InsertData i=new InsertData();
	i.insertData();	
    Retrive r=new Retrive();
    r.retriveDetail();
    Sorting s=new Sorting();
    s.sorting();
}

				
	}

